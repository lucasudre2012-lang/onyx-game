# Mini-site de jeux HTML
1) Mettez vos fichiers `.html` dans le dossier `games/` (avec leurs assets à côté si besoin).
2) Éditez `manifest.json` pour référencer chaque jeu (titre, fichier, genres).
3) Uploadez tout le dossier sur GitHub Pages / Netlify / Vercel.
4) Partagez l’URL : vos jeux seront jouables dans un lecteur intégré (iframe).

## Exemple d'entrée dans manifest.json
{
  "title": "Mon Super Jeu",
  "slug": "mon-super-jeu",
  "file": "mon-super-jeu.html",
  "description": "Description courte.",
  "genres": ["Action", "Arcade"],
  "cover": "assets/cover-mon-jeu.jpg"
}
